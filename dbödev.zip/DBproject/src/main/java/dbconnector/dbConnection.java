
package dbconnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author karag
 */
public class dbConnection {
    public dbConnection(){
}
    public Connection conn = null;
    public Connection connDb () {    
   
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ayakkabilar?zeroDateTimeBehavior=CONVERT_TO_NULL","root","1907");
            //JOptionPane.showMessageDialog(null,"Bağlandı");
}catch(Exception e){
            JOptionPane.showMessageDialog(null,e+"Bağlanamadı");
    

}
        return conn;
}
}