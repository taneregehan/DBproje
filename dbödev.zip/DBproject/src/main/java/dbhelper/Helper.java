/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dbhelper;

import javax.swing.JOptionPane;

/**
 *
 * @author karag
 */
public class Helper {


    public static void showMsj(String str){
        String msj;

        switch (str){
        case "fill":
            msj = "Lütfen Tüm Alanları Doldurunuz";
            break;
                    
        case "sifre":
            msj = "Sifreniz Aynı Değil";
            break; 
        
        default:
            msj = str;
    }

        JOptionPane.showMessageDialog(null, msj,"Mesaj",JOptionPane.INFORMATION_MESSAGE);



}

}

    
